package com.example.desafio_belo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
