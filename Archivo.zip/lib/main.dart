import 'package:desafio_belo/pages/convertir_page.dart';
import 'package:desafio_belo/pages/home_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      initialRoute: 'home',
      routes: {
        'home': (_) => const HomePage(),
        'convertir': (_) => const ConvertirPage(),
      },
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      //       home: ConvertirPage()
    );
  }
}
