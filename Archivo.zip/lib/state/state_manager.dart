import '../model/coingecko.dart';
import 'package:desafio_belo/network/network_request.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final coinStateFuture = FutureProvider<List<Coin>>((ref) async {
  return fetchCoins();
});
