import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../model/coingecko.dart';
import 'package:http/http.dart' as http;

List<Coin> parseCoins(String responseBody) {
  var list = json.decode(responseBody) as List<dynamic>;
  List<Coin> coins = list.map((model) => Coin.fromJson(model)).toList();
  return coins;
}

Future<List<Coin>> fetchCoins() async {
  final response = await http.get(Uri.parse(
      'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false'));

  if (response.statusCode == 200) {
    return compute(parseCoins, response.body);
  } else {
    throw Exception('No se pueden recuperar los simbolos');
  }
}
