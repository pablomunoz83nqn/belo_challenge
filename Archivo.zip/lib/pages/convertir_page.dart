import 'package:desafio_belo/model/coingecko.dart';
import 'package:desafio_belo/service/global.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:desafio_belo/state/state_manager.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class ConvertirPage extends StatefulWidget {
  const ConvertirPage({Key? key}) : super(key: key);

  @override
  State<ConvertirPage> createState() => _ConvertirPageState();
}

class _ConvertirPageState extends State<ConvertirPage> {
  final global = GlobalService();

  num? cantidad;

  @override
  Widget build(BuildContext context) {
    final Coin coin = ModalRoute.of(context)!.settings.arguments as Coin;
    debugPrint('$coin.ath');
    num? multiplicador =
        (cantidad != null) ? cantidad!.toInt() / coin.currentPrice!.toInt() : 0;

//Text(coin.symbol.toString()),
    // Text(coin.currentPrice.toString()),
    return Scaffold(
        body: Stack(alignment: Alignment.bottomCenter, children: [
      Home(),
      Positioned(
          top: MediaQuery.of(context).size.height * 0.27,
          left: 20,
          child: SizedBox(
            width: MediaQuery.of(context).size.width * .9,
            child: Card(
              elevation: 4.0,
              shadowColor: Colors.black,
              child: Container(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        SizedBox(
                          height: 56,
                          child: Image(
                            image: NetworkImage(coin.image.toString()),
                          ),
                        ),
                        Column(
                          children: [
                            Text(
                              'Disponible>  ${(global.criptosMap[coin.symbol] ?? '0')}',
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              'Precio Actual> USD  ' +
                                  coin.currentPrice.toString(),
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                          ],
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 15.0,
                    ),
                    Row(
                      children: [
                        const SizedBox(
                          width: 20,
                        ),
                        const SizedBox(child: Text('USD')),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          flex: 1,
                          child: TextField(
                            keyboardType: TextInputType.number,
                            onChanged: (String? newValue2) {
                              cantidad = (cantidad != null)
                                  ? double.tryParse(newValue2!)
                                  : 1;
                              setState(() {});
                            },
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: 'Cantidad a convertir',
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Card(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            '${coin.symbol}'.toUpperCase(),
                            style: const TextStyle(fontSize: 20),
                          ),
                          Text(
                            '$multiplicador',
                            style: const TextStyle(
                                fontSize: 20, color: Colors.green),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20.0,
                    ),
                    Card(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          RaisedButton(
                            child: const Text("Vender USD"),
                            onPressed: () {
                              (cantidad == null)
                                  ? Alert(
                                          context: context,
                                          title: "Alerta!",
                                          desc: "La cantidad no puede ser 0")
                                      .show()
                                  : Alert(
                                      context: context,
                                      type: AlertType.warning,
                                      title: "Confirmacion ",
                                      desc:
                                          "Confirmar VENTA de USD $cantidad por la cantidad de $multiplicador ${coin.symbol} ",
                                      buttons: [
                                        DialogButton(
                                          child: const Text(
                                            "Aceptar",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20),
                                          ),
                                          onPressed: () {
                                            (global.criptosMap[coin.symbol] ==
                                                    null)
                                                ? global.criptosMap[coin.symbol
                                                    .toString()] = multiplicador
                                                : global.criptosMap[coin.symbol
                                                        .toString()] =
                                                    global.criptosMap[coin
                                                            .symbol
                                                            .toString()]! +
                                                        multiplicador;
                                            global.criptosMap['usd'] =
                                                global.criptosMap['usd']! -
                                                    cantidad!;

                                            setState(() {});
                                            Navigator.pop(context);
                                          },
                                          color: const Color.fromRGBO(
                                              0, 179, 134, 1.0),
                                        ),
                                        DialogButton(
                                          child: const Text(
                                            "Cancelar",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20),
                                          ),
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          gradient:
                                              const LinearGradient(colors: [
                                            Color.fromRGBO(116, 116, 191, 1.0),
                                            Color.fromRGBO(52, 138, 199, 1.0)
                                          ]),
                                        )
                                      ],
                                    ).show();
                            },
                            color: Colors.red,
                            textColor: Colors.yellow,
                            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                            splashColor: Colors.grey,
                          ),
                          RaisedButton(
                            child: const Text("Comprar USD"),
                            onPressed: () {
                              (cantidad == null)
                                  ? Alert(
                                          context: context,
                                          title: "Alerta!",
                                          desc: "La cantidad no puede ser 0")
                                      .show()
                                  : (global.criptosMap[coin.symbol] == null ||
                                          global.criptosMap[coin.symbol]! <
                                              multiplicador)
                                      ? Alert(
                                              image: Image.network(
                                                  'http://cdn.onlinewebfonts.com/svg/img_455745.png'),
                                              context: context,
                                              title: "Alerta!",
                                              desc:
                                                  "Fondos Insuficientes, controle su disponible")
                                          .show()
                                      : Alert(
                                          context: context,
                                          type: AlertType.warning,
                                          title: "Confirmacion ",
                                          desc:
                                              "Confirmar COMPRA de USD $cantidad por la cantidad de $multiplicador ${coin.symbol} ",
                                          buttons: [
                                            DialogButton(
                                              child: const Text(
                                                "Aceptar",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20),
                                              ),
                                              onPressed: () {
                                                global.criptosMap[coin.symbol
                                                        .toString()] =
                                                    global.criptosMap[coin
                                                            .symbol
                                                            .toString()]! -
                                                        multiplicador;

                                                global.criptosMap['usd'] =
                                                    global.criptosMap['usd']! +
                                                        cantidad!;

                                                setState(() {});
                                                Navigator.pop(context);
                                              },
                                              color: const Color.fromRGBO(
                                                  0, 179, 134, 1.0),
                                            ),
                                            DialogButton(
                                              child: const Text(
                                                "Cancelar",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20),
                                              ),
                                              onPressed: () =>
                                                  Navigator.pop(context),
                                              gradient: const LinearGradient(
                                                  colors: [
                                                    Color.fromRGBO(
                                                        116, 116, 191, 1.0),
                                                    Color.fromRGBO(
                                                        52, 138, 199, 1.0)
                                                  ]),
                                            )
                                          ],
                                        ).show();
                            },
                            color: Colors.green,
                            textColor: Colors.yellow,
                            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                            splashColor: Colors.grey,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: const [
                            Text(
                              'Portfolio',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 15),
                            ),
                            Text(
                              'Esconder los balances en 0',
                              style:
                                  TextStyle(fontSize: 10, color: Colors.grey),
                            ),
                            Icon(Icons.check_box_sharp)
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * .3,
                          child: ListView.builder(
                            itemCount: global.criptosMap.length,
                            itemBuilder: (BuildContext context, int index) {
                              String key =
                                  global.criptosMap.keys.elementAt(index);
                              return Column(
                                children: <Widget>[
                                  ListTile(
                                    title: Text(key.toUpperCase()),
                                    subtitle: Text("${global.criptosMap[key]}"),
                                  ),
                                  const Divider(
                                    height: 1.0,
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          )),
      Visibility(
        visible: (global.esconderBoton == true) ? false : true,
        child: Positioned(
          bottom: MediaQuery.of(context).size.height * .03,
          left: MediaQuery.of(context).size.width * .05,
          child: RaisedButton(
              // padding: EdgeInsets.all(20),
              padding: const EdgeInsets.symmetric(
                vertical: 18.0,
                horizontal: 38.0,
              ),
              color: const Color(0xFFEE112D),
              onPressed: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0)),
              child: const Text(
                "Enviar",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              )),
        ),
      ),
      Visibility(
        visible: (global.esconderBoton == true) ? false : true,
        child: Positioned(
          bottom: MediaQuery.of(context).size.height * .03,
          right: MediaQuery.of(context).size.width * .05,
          child: RaisedButton(
              padding: const EdgeInsets.symmetric(
                vertical: 18.0,
                horizontal: 30.0,
              ),
              color: const Color(0xFFEE112D),
              onPressed: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0)),
              child: const Text(
                "Recibir",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              )),
        ),
      ),
      Positioned(
        bottom: MediaQuery.of(context).size.height * 0.02,
        left: MediaQuery.of(context).size.width * .45,
        child: FloatingActionButton(
          backgroundColor: Colors.black54,
          onPressed: () {
            setState(() {
              (global.esconderBoton == false)
                  ? global.esconderBoton = true
                  : global.esconderBoton = false;
            });
          },
          child: Icon(
            (global.esconderBoton == true)
                ? Icons.menu_open
                : Icons.arrow_downward_rounded,
            color: Colors.deepOrange,
          ),
        ),
      ),
    ]));
  }

  @override
  void initState() {
    global.criptosMap['usd'];
    global.criptosMap;
    global.esconderBoton = true;
    super.initState();
  }
}

class Home extends ConsumerWidget {
  Home({Key? key}) : super(key: key);
  final global = GlobalService();

  @override
  Widget build(BuildContext context,
      T Function<T>(ProviderBase<Object, T> provider) watch) {
    AsyncValue<List<Coin>> coins = watch(coinStateFuture);
    return Scaffold(
      backgroundColor: const Color(0xFFDAD3DC),
      /*  appBar: AppBar(
        backgroundColor: Colors.black54,
        title: Text(
          'Riverpod GET CoinGecko API',
          style: TextStyle(color: Colors.redAccent),
        ),
      ), */
      body: coins.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, stack) => Center(child: Text('$err')),
          data: (coins) {
            return Stack(
              children: [
                Column(
                  children: <Widget>[
                    Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF81269D), Color(0xFFEE112D)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          // stops: [0.0, 0.1],
                        ),
                      ),
                      height: MediaQuery.of(context).size.height * .30,
                      padding:
                          const EdgeInsets.only(top: 55, left: 20, right: 20),
                    ),
                  ],
                ),
                Positioned(
                  width: MediaQuery.of(context).size.height * .90,
                  top: 205,
                  child: SizedBox(
                    height: MediaQuery.of(context).size.height * .9,
                    child: Container(),
                  ),
                ),
                Positioned(
                  top: 20,
                  left: 20,
                  child: Column(
                    children: <Widget>[
                      Center(
                        widthFactor: 1.3,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            IconButton(
                              icon: const Icon(
                                Icons.menu,
                                color: Colors.white,
                              ),
                              onPressed: () {},
                            ),
                            const Text("Tu balance (24H)",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.w500)),
                            IconButton(
                              icon: const Icon(
                                Icons.notification_add,
                                color: Colors.white,
                              ),
                              onPressed: () {},
                            )
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        r'U$D ' '${global.criptosMap['usd']}'.toString(),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 45.0,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        r'BTC ' '${double.parse((global.criptosMap['btc']!).toDouble().toStringAsFixed(4))}'
                            .toString(),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 25.0,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        r'U$D'
                        '${global.criptosMap['usd']! - (global.criptosMap['usd']! * 5 / 100)}  (5%)',
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w300),
                      ),
                      const SizedBox(
                        height: 20,
                      )
                    ],
                  ),
                ),
              ],
            );
          }),
    );
  }
}
