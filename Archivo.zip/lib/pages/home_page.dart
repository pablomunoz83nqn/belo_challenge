import 'package:desafio_belo/model/coingecko.dart';
import 'package:desafio_belo/service/global.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:desafio_belo/state/state_manager.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final global = GlobalService();

  @override
  void initState() {
    global.criptosMap;

    global.esconderBoton = true;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(alignment: Alignment.bottomCenter, children: [
      Home(),
      Visibility(
        visible: (global.esconderBoton == true) ? false : true,
        child: Positioned(
          bottom: MediaQuery.of(context).size.height * .03,
          left: MediaQuery.of(context).size.width * .05,
          child: RaisedButton(
              // padding: EdgeInsets.all(20),
              padding: const EdgeInsets.symmetric(
                vertical: 18.0,
                horizontal: 38.0,
              ),
              color: const Color(0xFFEE112D),
              onPressed: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0)),
              child: const Text(
                "Enviar",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              )),
        ),
      ),
      Visibility(
        visible: (global.esconderBoton == true) ? false : true,
        child: Positioned(
          bottom: MediaQuery.of(context).size.height * .03,
          right: MediaQuery.of(context).size.width * .05,
          child: RaisedButton(
              padding: const EdgeInsets.symmetric(
                vertical: 18.0,
                horizontal: 30.0,
              ),
              color: const Color(0xFFEE112D),
              onPressed: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0)),
              child: const Text(
                "Recibir",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              )),
        ),
      ),
      Positioned(
        bottom: MediaQuery.of(context).size.height * 0.02,
        left: MediaQuery.of(context).size.width * .45,
        child: FloatingActionButton(
          backgroundColor: Colors.black54,
          onPressed: () {
            setState(() {
              (global.esconderBoton == false)
                  ? global.esconderBoton = true
                  : global.esconderBoton = false;
            });
          },
          child: Icon(
            (global.esconderBoton == true)
                ? Icons.menu_open
                : Icons.arrow_downward_rounded,
            color: Colors.deepOrange,
          ),
        ),
      ),
    ]));
  }
}

class Home extends ConsumerWidget {
  Home({Key? key}) : super(key: key);
  final global = GlobalService();

  @override
  Widget build(BuildContext context,
      T Function<T>(ProviderBase<Object, T> provider) watch) {
    AsyncValue<List<Coin>> coins = watch(coinStateFuture);
    return Scaffold(
      backgroundColor: const Color(0xFFE4D2E9),
      body: coins.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, stack) => Center(child: Text('$err')),
          data: (coins) {
            return Stack(
              children: [
                Column(
                  children: <Widget>[
                    Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF81269D), Color(0xFF8A0416)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          stops: [0.2, 1],
                        ),
                      ),
                      height: MediaQuery.of(context).size.height * .30,
                      padding:
                          const EdgeInsets.only(top: 55, left: 20, right: 20),
                    ),
                  ],
                ),
                Positioned(
                  width: MediaQuery.of(context).size.height * .50,
                  top: 220,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    child: InputDecorator(
                      decoration: InputDecoration(
                        enabledBorder: const OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.white, width: 1.0),
                        ),
                        labelText: 'Convertir',
                        labelStyle: const TextStyle(color: Colors.white),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      child: SizedBox(
                        height: MediaQuery.of(context).size.height * .9,
                        child: ListView.builder(
                            itemCount: coins.length,
                            itemBuilder: (context, index) {
                              // Calculo el balance y lo redondeo a 3 decimales
                              double calculo =
                                  global.criptosMap['usd']!.toInt() /
                                      coins[index].currentPrice!.toInt();
                              double balance =
                                  double.parse((calculo).toStringAsFixed(3));
                              double cambio24hsCalculo =
                                  coins[index].low24h!.toDouble() -
                                      coins[index].currentPrice!.toDouble();
                              double cambio24hs = double.parse(
                                  (cambio24hsCalculo).toStringAsFixed(2));
                              double market24cap = double.parse(
                                  (coins[index].marketCapChangePercentage24h!)
                                      .toDouble()
                                      .toStringAsFixed(2));

                              return GestureDetector(
                                onTap: () => Navigator.pushNamed(
                                    context, 'convertir',
                                    arguments: coins[index]),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(25),
                                  child: Card(
                                      elevation: 3.0,
                                      child: Container(
                                        padding: const EdgeInsets.all(3.0),
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              height: 40,
                                              child: Image(
                                                  image: NetworkImage(
                                                      '${coins[index].image}'
                                                          .toString())),
                                            ),
                                            const SizedBox(
                                              width: 20,
                                            ),
                                            Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Text(
                                                      '${coins[index].symbol}'
                                                          .toUpperCase(),
                                                      style: const TextStyle(
                                                        fontSize: 25.0,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                    const SizedBox(width: 30),
                                                    Text(
                                                      'USD '
                                                      '${double.parse((coins[index].currentPrice!).toDouble().toStringAsFixed(4))}',
                                                      style: const TextStyle(
                                                        fontSize: 20.0,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(height: 10.0),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceAround,
                                                  children: <Widget>[
                                                    Text('$balance',
                                                        style: const TextStyle(
                                                            fontSize: 22.0,
                                                            color: Colors.grey,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold)),
                                                    const SizedBox(
                                                      width: 10.0,
                                                    ),
                                                    Text(
                                                        r'$'
                                                        '$cambio24hs'
                                                        ' / (% $market24cap)',
                                                        style: TextStyle(
                                                            color:
                                                                (market24cap >
                                                                        0)
                                                                    ? Colors
                                                                        .green
                                                                    : Colors
                                                                        .red,
                                                            fontSize: 15.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold)),
                                                  ],
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      )),
                                ),
                              );
                            }),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 20,
                  left: 20,
                  child: Column(
                    children: <Widget>[
                      Center(
                        widthFactor: 1.3,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            IconButton(
                              icon: const Icon(
                                Icons.menu,
                                color: Colors.white,
                              ),
                              onPressed: () {},
                            ),
                            const Text("Tu balance (24H)",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.w500)),
                            IconButton(
                              icon: const Icon(
                                Icons.notification_add,
                                color: Colors.white,
                              ),
                              onPressed: () {},
                            )
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        r'U$D ' '${global.criptosMap['usd']}'.toString(),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 45.0,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        r'BTC '
                        '${double.parse((global.criptosMap['btc']!).toDouble().toStringAsFixed(4))}',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        r'U$D'
                        '${global.criptosMap['usd']! - (global.criptosMap['usd']! * 5 / 100)}  (5%)',
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w300),
                      ),
                      const SizedBox(
                        height: 20,
                      )
                    ],
                  ),
                ),
              ],
            );
          }),
    );
  }
}
