class GlobalService {
  //this Singleton keeps in memory instance of class
  static final GlobalService _singleton = GlobalService._internal();

  factory GlobalService() {
    return _singleton;
  }

  GlobalService._internal();

  //Total of vehicles in Non Toll Mode on account for dashboard
  num balanceUsd = 1500;
  num? balanceBtc = 0;
  bool esconderBoton = true;
  String convertirSimbolo = '';

  final Map<String, num> criptosMap = {
    "btc": 0.003,
    "usd": 2300,
    "eth": 0.4747979992304733
  };
}
